/* 외부 스크립트 */
console.log("Hello Javascript");