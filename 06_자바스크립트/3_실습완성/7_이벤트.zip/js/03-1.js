3/* js/03-1.js */

function loadEnd1 () { alert('loadEnd1() 실행'); }

// window.onload = loadEnd1;
window.addEventListener( 'load', loadEnd1 );