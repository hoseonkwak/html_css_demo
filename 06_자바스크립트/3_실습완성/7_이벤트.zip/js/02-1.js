/* js/02-1.js */

function loadEnd1 () { alert('loadEnd1() 실행'); }

window.onload = loadEnd1;
