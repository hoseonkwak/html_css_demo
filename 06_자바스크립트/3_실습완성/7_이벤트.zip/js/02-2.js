/* js/02-2.js */

function loadEnd2 () { alert('loadEnd2() 실행'); }

window.onload = loadEnd2;