/* js/output.js */

// 기본 출력 함수
function prn ( obj ) {
  document.write('<p>' + obj);
}

// 라인 출력 함수
function line () {
  document.write('<hr>');
}